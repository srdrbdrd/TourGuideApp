package com.example.android.tourguideapp;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Serdar on 03.06.2018.
 */

public class PlaceAdapter extends ArrayAdapter<Place> {

    private int mColorResourceId;


    public PlaceAdapter(Context context, ArrayList<Place> place, int colorResourceId) {
        super(context, 0, place);
        mColorResourceId = colorResourceId;
    }

    static class ViewHolder {
        TextView name;
        TextView address;
        ImageView icon;
        TextView phone;

    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if an existing view is being reused, otherwise inflate the view
        ViewHolder holder;

        if (null == convertView) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
            holder = new ViewHolder();
            holder.name = (TextView) convertView.findViewById(R.id.list_item_name);
            holder.address = (TextView) convertView.findViewById(R.id.list_item_address);
            holder.phone = (TextView) convertView.findViewById(R.id.list_item_phone);
            holder.icon = (ImageView) convertView.findViewById(R.id.list_item_image);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        Place place = getItem(position);

        holder.name.setText(place.gettName());
        holder.address.setText(place.gettAddress());
        holder.phone.setText(place.gettPhone());
        holder.icon.setImageResource(place.gettImageResource());

        View textContainer = convertView.findViewById(R.id.text_container);

        int color = ContextCompat.getColor(getContext(), mColorResourceId);

        textContainer.setBackgroundColor(color);


        return convertView;
    }
}
