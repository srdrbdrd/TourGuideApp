package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * Created by Serdar on 06.06.2018.
 */

public class HospitalFragment extends Fragment {

    public HospitalFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list, container, false);
        final ArrayList<Place> places = new ArrayList<Place>();
        places.add(new Place(getContext().getString(R.string.hospital), getContext().getString(R.string.haddress1), getContext().getString(R.string.hphone1), R.drawable.hastabe1));
        places.add(new Place(getContext().getString(R.string.hospital2), getContext().getString(R.string.haddress2), getContext().getString(R.string.hphone2), R.drawable.hastane3));
        places.add(new Place(getContext().getString(R.string.hospital3), getContext().getString(R.string.haddress3), getContext().getString(R.string.hphone3), R.drawable.hastane2));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.tan_background);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;


    }
}


