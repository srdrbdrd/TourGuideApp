package com.example.android.tourguideapp;

import android.provider.ContactsContract;

/**
 * Created by Serdar on 03.06.2018.
 */

public class Place {
    private String tName;
    private String tAddress;
    private String tPhone;
    private int tImageResource;

    public Place(String Name, String Address, String Phone, int ImageResource) {
        tName = Name;
        tAddress = Address;
        tPhone = Phone;
        tImageResource = ImageResource;
    }

    public String gettPhone() {
        return tPhone;
    }

    public String gettName() {
        return tName;
    }

    public String gettAddress() {
        return tAddress;
    }

    public int gettImageResource() {
        return tImageResource;
    }
}
