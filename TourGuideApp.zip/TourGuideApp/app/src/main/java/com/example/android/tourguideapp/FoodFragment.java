package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Serdar on 05.06.2018.
 */

public class FoodFragment extends Fragment {

    @Override
    public void onStop() {
        super.onStop();
    }

    public FoodFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list, container, false);
        final ArrayList<Place> places = new ArrayList<Place>();
        places.add(new Place(getContext().getString(R.string.food1), getContext().getString(R.string.faddress1), getContext().getString(R.string.fphone1), R.drawable.istanbul));
        places.add(new Place(getContext().getString(R.string.food2), getContext().getString(R.string.faddress2), getContext().getString(R.string.fphone2), R.drawable.sans));
        places.add(new Place(getContext().getString(R.string.food3), getContext().getString(R.string.faddress3), getContext().getString(R.string.fphone3), R.drawable.ottoman));
        places.add(new Place(getContext().getString(R.string.food4), getContext().getString(R.string.faddress4), getContext().getString(R.string.fphone4), R.drawable.nterr));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.tan_background);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;


    }

}
