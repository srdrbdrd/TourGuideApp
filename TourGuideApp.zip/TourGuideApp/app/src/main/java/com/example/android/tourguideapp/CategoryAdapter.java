package com.example.android.tourguideapp;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


/**
 * Created by Serdar on 04.06.2018.
 */

public class CategoryAdapter extends FragmentPagerAdapter {

    /**
     * Context of the app
     */
    private Context pContext;

    /**
     * Create a new {@link CategoryAdapter} object.
     *
     * @param context is the context of the app
     * @param fm      is the fragment manager that will keep each fragment's state in the adapter
     *                across swipes.
     */
    public CategoryAdapter(Context context, FragmentManager fm) {
        super(fm);
        pContext = context;
    }

    /**
     * Return the {@link Fragment} that should be displayed for the given page number.
     */
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new AccommodationFragment();
        } else if (position == 1) {
            return new FoodFragment();
        } else if (position == 2) {
            return new NightlifeFragment();
        } else if (position == 3) {
            return new HospitalFragment();
        } else {
            return new IstanbulFragment();
        }

    }

    /**
     * Return the total number of pages.
     */
    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return pContext.getString(R.string.fragment1);
        } else if (position == 1) {
            return pContext.getString(R.string.fragment2);
        } else if (position == 2) {
            return pContext.getString(R.string.fragment3);
        } else if (position == 3) {
            return pContext.getString(R.string.hospitals);
        } else {
            return pContext.getString(R.string.fragment4);
        }
    }
}


