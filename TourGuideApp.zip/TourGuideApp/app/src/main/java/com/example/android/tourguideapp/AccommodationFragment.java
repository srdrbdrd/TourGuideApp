package com.example.android.tourguideapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Serdar on 04.06.2018.
 */

public class AccommodationFragment extends Fragment {

    @Override
    public void onStop() {
        super.onStop();
    }

    public AccommodationFragment() {

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.list, container, false);
        final ArrayList<Place> places = new ArrayList<Place>();
        places.add(new Place(getContext().getString(R.string.accommodiation1), getContext().getString(R.string.address1), getContext().getString(R.string.phone1), R.drawable.mowenpick));
        places.add(new Place(getContext().getString(R.string.accommodiation2), getContext().getString(R.string.address2), getContext().getString(R.string.phone2), R.drawable.hilton));
        places.add(new Place(getContext().getString(R.string.accommodiation3), getContext().getString(R.string.address3), getContext().getString(R.string.phone3), R.drawable.sirkeci));
        places.add(new Place(getContext().getString(R.string.accomodiation4), getContext().getString(R.string.address4), getContext().getString(R.string.phone4), R.drawable.gezi));
        places.add(new Place(getContext().getString(R.string.accommodiation5), getContext().getString(R.string.address5), getContext().getString(R.string.phone5), R.drawable.wist));
        PlaceAdapter adapter = new PlaceAdapter(getActivity(), places, R.color.tan_background);
        ListView listView = (ListView) rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;


    }
}
